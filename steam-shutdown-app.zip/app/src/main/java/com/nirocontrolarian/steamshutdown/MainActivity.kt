package com.nirocontrolarian.steamshutdown

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * مدل داده هر نقطه شات‌دان.
 * @param label    برچسب زمانی (مثلاً "1:10")
 * @param minute   دقیقه مرجع از شروع برنامه
 * @param pressure فشار بخار اصلی (MPa)
 * @param load     بار واحد (MW)
 * @param temp     دمای بخار اصلی (C)
 */
data class Reading(val label: String, val minute: Int, val pressure: Double, val load: Double, val temp: Double)

class MainActivity : AppCompatActivity() {

    // جدول مرجع شات‌دان واحد بخار: ۱۹ نقطه از 0:00 تا 3:00
    private val data: List<Reading> = listOf(
        Reading("0:00", 0, 16.70, 325.0, 540.0),
        Reading("0:10", 10, 15.68, 307.8, 529.5),
        Reading("0:20", 20, 14.66, 290.6, 519.0),
        Reading("0:30", 30, 13.64, 273.4, 508.5),
        Reading("0:40", 40, 12.62, 256.2, 498.0),
        Reading("0:50", 50, 11.60, 239.0, 487.5),
        Reading("1:00", 60, 10.58, 221.8, 477.0),
        Reading("1:10", 70, 9.56, 204.6, 466.5),
        Reading("1:20", 80, 8.54, 187.4, 456.0),
        Reading("1:30", 90, 7.52, 170.2, 445.5),
        Reading("1:40", 100, 6.50, 153.0, 435.0),
        Reading("1:50", 110, 5.48, 135.8, 424.5),
        Reading("2:00", 120, 4.46, 118.6, 414.0),
        Reading("2:10", 130, 3.44, 101.4, 403.5),
        Reading("2:20", 140, 3.44, 84.2, 393.0),
        Reading("2:30", 150, 3.44, 67.0, 382.5),
        Reading("2:40", 160, 3.44, 49.8, 372.0),
        Reading("2:50", 170, 3.44, 32.6, 361.5),
        Reading("3:00", 180, 3.44, 15.4, 351.0)
    )

    companion object {
        private const val TOTAL_MINUTES = 180
        // آستانه تشخیص صفحه‌شدن (plateau): تغییر کمتر از این مقدار بین دو نقطه مجاور
        private const val PLATEAU_EPS = 1e-6
        private const val KEY_ELAPSED = "elapsed"
        private const val KEY_RUNNING = "running"
        private const val KEY_SELECTED = "selected"
    }

    private lateinit var timerText: TextView
    private lateinit var statusText: TextView
    private lateinit var currentInfoText: TextView
    private lateinit var tableContainer: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var resetBtn: Button

    private var elapsedSeconds = 0
    private var running = false
    private var selectedRow = -1
    private val rowViews = mutableListOf<TableRow>()

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            elapsedSeconds++
            if (elapsedSeconds >= TOTAL_MINUTES * 60) {
                elapsedSeconds = TOTAL_MINUTES * 60
                running = false
                onFinish()
            }
            updateUi()
            if (running) handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()

        if (savedInstanceState != null) {
            elapsedSeconds = savedInstanceState.getInt(KEY_ELAPSED, 0)
            selectedRow = savedInstanceState.getInt(KEY_SELECTED, -1)
            if (savedInstanceState.getBoolean(KEY_RUNNING, false) && elapsedSeconds < TOTAL_MINUTES * 60) {
                running = true
                handler.postDelayed(tick, 1000)
            }
        }
        updateUi()
    }

    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#0D1B3E"))
        }

        val title = TextView(this).apply {
            text = "جدول شات‌دان واحد بخار"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        timerText = TextView(this).apply {
            textSize = 40f
            setTextColor(Color.parseColor("#4ADE80"))
            gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
        }
        root.addView(timerText)

        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 8)
        }
        root.addView(statusText)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = TOTAL_MINUTES * 60
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4ADE80"))
        }
        root.addView(progress)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        startBtn = Button(this).apply { text = "شروع" }
        pauseBtn = Button(this).apply { text = "توقف" }
        resetBtn = Button(this).apply { text = "بازنشانی" }
        listOf(startBtn, pauseBtn, resetBtn).forEach { b ->
            b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = 8
            }
            btnRow.addView(b)
        }
        root.addView(btnRow)

        currentInfoText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        root.addView(currentInfoText)

        tableContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val headerLabels = listOf("زمان", "دقیقه", "فشار (MPa)", "بار (MW)", "دما (°C)")
        val header = TableRow(this)
        headerLabels.forEach { h ->
            header.addView(TextView(this).apply {
                text = h
                setTextColor(Color.WHITE)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(6, 10, 6, 10)
            })
        }
        tableContainer.addView(header)

        data.forEachIndexed { idx, row ->
            val tr = TableRow(this)
            val cells = listOf(row.label, row.minute.toString(), fmt2(row.pressure), fmt1(row.load), fmt1(row.temp))
            cells.forEach { v ->
                val tv = TextView(this).apply {
                    text = v
                    setTextColor(Color.WHITE)
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setPadding(6, 10, 6, 10)
                }
                tr.addView(tv)
            }
            tr.tag = idx
            tr.isClickable = true
            tr.setOnClickListener {
                selectedRow = if (selectedRow == idx) -1 else idx
                updateUi()
            }
            tableContainer.addView(tr)
            rowViews.add(tr)
        }

        scroll.addView(tableContainer)
        root.addView(scroll)
        setContentView(root)

        startBtn.setOnClickListener {
            if (elapsedSeconds >= TOTAL_MINUTES * 60) {
                Toast.makeText(this, "برنامه پایان یافته است؛ ابتدا بازنشانی کنید", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            running = true
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, 1000)
            updateUi()
        }
        pauseBtn.setOnClickListener {
            running = false
            handler.removeCallbacks(tick)
            updateUi()
        }
        resetBtn.setOnClickListener {
            running = false
            elapsedSeconds = 0
            selectedRow = -1
            statusText.text = ""
            statusText.setTextColor(Color.WHITE)
            handler.removeCallbacks(tick)
            updateUi()
        }
    }

    /** نرمال‌سازی عددی: تبدیل مطمئن رشته به Double (حذف جداکننده هزارگان/فاصله، پشتیبانی از ممیز فارسی/عربی). */
    private fun normalizeNumeric(raw: String): Double? {
        val cleaned = raw.trim()
            .replace('\u066B', '.')   // ممیز عربی
            .replace('\u066C', ',')   // جداکننده هزارگان عربی
            .replace('٫', '.')        // ممیز فارسی
            .replace('٬', ',')        // جداکننده هزارگان فارسی
            .replace(",", "")
            .replace(" ", "")
        return cleaned.toDoubleOrNull()
    }

    /** قالب‌بندی دو رقم اعشار. */
    private fun fmt2(v: Double): String = String.format("%.2f", v)

    /** قالب‌بندی یک رقم اعشار. */
    private fun fmt1(v: Double): String = String.format("%.1f", v)

    /** درون‌یابی خطی مقدار در دقیقه m بین نقاط جدول مرجع. */
    private fun interpolateAt(m: Double, selector: (Reading) -> Double): Double? {
        if (data.isEmpty()) return null
        if (m <= data.first().minute) return selector(data.first())
        if (m >= data.last().minute) return selector(data.last())
        for (i in 0 until data.size - 1) {
            val a = data[i]
            val b = data[i + 1]
            if (m >= a.minute && m <= b.minute) {
                val span = (b.minute - a.minute).toDouble()
                if (span <= 0.0) return selector(a)
                val t = (m - a.minute) / span
                return selector(a) + t * (selector(b) - selector(a))
            }
        }
        return selector(data.last())
    }

    /** بررسی صفحه‌شدن (plateau): true اگر مقدار از این نقطه تا انتها تغییر معنادار نکند. */
    private fun isPlateau(fromIdx: Int, selector: (Reading) -> Double): Boolean {
        if (fromIdx < 0 || fromIdx >= data.size - 1) return true
        val base = selector(data[fromIdx])
        for (i in fromIdx until data.size) {
            if (Math.abs(selector(data[i]) - base) > PLATEAU_EPS) return false
        }
        return true
    }

    private fun currentRowIdx(): Int {
        val m = elapsedSeconds / 60
        var idx = -1
        for (i in data.indices) {
            if (m >= data[i].minute) idx = i
        }
        return idx
    }

    private fun onFinish() {
        statusText.text = "برنامه شات‌دان پایان یافت"
        statusText.setTextColor(Color.parseColor("#F87171"))
    }

    private fun updateUi() {
        val mm = elapsedSeconds / 60
        val ss = elapsedSeconds % 60
        timerText.text = String.format("%02d:%02d", mm, ss)
        progress.progress = elapsedSeconds

        val idx = currentRowIdx()
        val exactMin = elapsedSeconds / 60.0

        if (selectedRow >= 0) {
            val row = data[selectedRow]
            val plateauNote = if (isPlateau(selectedRow) { it.pressure }) " (صفحه فشار)" else ""
            currentInfoText.text = "نقطه انتخابی: " + row.label + "  |  فشار: " + fmt2(row.pressure) + " MPa" +
                plateauNote + "  |  بار: " + fmt1(row.load) + " MW  |  دما: " + fmt1(row.temp) + " °C"
        } else if (idx >= 0) {
            val p = interpolateAt(exactMin) { it.pressure }
            val l = interpolateAt(exactMin) { it.load }
            val t = interpolateAt(exactMin) { it.temp }
            val nextIdx = if (idx < data.size - 1) idx + 1 else idx
            val plateauNote = if (isPlateau(idx) { it.pressure }) " (صفحه فشار)" else ""
            currentInfoText.text = "نقطه هدف فعلی: " + data[idx].label + " تا " + data[nextIdx].label +
                "  |  فشار: " + fmt2(p) + " MPa" + plateauNote +
                "  |  بار: " + fmt1(l) + " MW  |  دما: " + fmt1(t) + " °C"
        } else {
            currentInfoText.text = "-"
        }

        rowViews.forEachIndexed { i, tr ->
            val active = (i == idx && selectedRow == -1) || i == selectedRow
            tr.setBackgroundColor(if (active) Color.parseColor("#14532D") else Color.TRANSPARENT)
        }

        startBtn.isEnabled = !running
        pauseBtn.isEnabled = running
        if (running) {
            statusText.text = "در حال اجرا..."
            statusText.setTextColor(Color.WHITE)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_ELAPSED, elapsedSeconds)
        outState.putBoolean(KEY_RUNNING, running)
        outState.putInt(KEY_SELECTED, selectedRow)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(tick)
    }
}
